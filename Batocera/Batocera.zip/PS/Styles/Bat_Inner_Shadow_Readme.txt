The style is intended to be used on a filled opaque object that is 2 pixels larger than the hole in the layer and below it in layer order.

It will set the fill to 0 and apply an inner shadow.